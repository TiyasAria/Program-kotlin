fun main() {
    var firstName : String = "Tiyas Aria"
    var lastName : String = "Pratiwi"
     // var fullname : String = "tiyas aria pratiwi"
    // string tanda + untuk menggabungkan
  // var fullName : String = firstName + " " + lastName
    var fullName : String = " $firstName $lastName "
    var desc : String = "Total = $fullName , Character ${fullName.length} "

    var address: String = """
        *Banaran RT 06, Suwatu
        *Tanon, Sragen Asri 
    """.trimMargin(  "*")

    println(firstName)
    println(lastName)
    println(fullName)
    println(address)
    println(desc)
}