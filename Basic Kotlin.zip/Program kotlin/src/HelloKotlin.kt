fun main () {
    println(" Hello Word")
    println(" Hello Word")
    println(" Hello Word")
    println(" Hello my name is Aria, I come from Sragen  ")
    print(" hi :)")
    println("Aria do you remember Me ?")

    println(Application)
}