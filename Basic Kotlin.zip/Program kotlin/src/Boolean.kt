fun main() {
    var benar : Boolean = true
    var salah : Boolean = false
    println(benar)
    println(salah)
    




}