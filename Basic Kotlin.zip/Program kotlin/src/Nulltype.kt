fun main() {
    var nama : String
    var umur : String?
    nama = "Tiyas Aria"
    umur = null
    println(nama)
    println(umur)
// safe call (?.)
    var stringNull : String? = null
    println(stringNull?.length)

//elvis operator
    var text : String? = null
    var textLength = text?.length ?: "Tiyas Aria"
    println(textLength)

}