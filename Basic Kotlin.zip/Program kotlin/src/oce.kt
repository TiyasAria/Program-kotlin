fun main() {
    val buah = "Pisang"

}