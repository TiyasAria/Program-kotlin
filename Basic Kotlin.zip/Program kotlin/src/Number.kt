fun main (){
    // integer number
    var age : Byte = 18
    var high : Int = 169
    var distance : Short = 2000
    var balance : Long = 100000000L
    println(age)
  println(high)
    println(distance)
    println ( balance)

    //float number
    var value : Float = 98.98F
    var radius : Double = 2727272.345
    println(value)
    println(radius)

    // conversion
    var umur : Int = 150
    var byte  : Byte = umur.toByte()
    var short : Short = umur.toShort()
    var long : Long = umur.toLong()
    var float : Float = umur.toFloat()
    var double : Double = umur.toDouble()

    println(byte)
    println(short)
    println(long)
    println(float)
    println(double)




}