package operasiMatematika

fun main() {
    // memiliki beberapa simbol klau simbolnya && (AND) kalau  || (OR) kalau ! (NOT/kebalikan)//
    val nilaiAkhir = 80
    val nilaiKehadiran = 70
    val nilaiExtra = 50

    val passNilaiAkhir = nilaiAkhir > 75 //true
    val passNilaiKehadiran = nilaiKehadiran > 75 //false
    val passNilaiExtra = nilaiExtra > 75 //false
    val pass = passNilaiAkhir || passNilaiKehadiran && passNilaiExtra
    println(pass)

    val nilaiUjian = 90
    val nilaiAbsen = 80
    val nilaiEkstra = 55

    val apaLulusUjian = nilaiUjian > 70
    val apaLulusAbsen = nilaiAbsen > 70
    val apaLulusEkstra = nilaiEkstra > 60
    val apaLulus = apaLulusUjian && apaLulusAbsen && apaLulusEkstra
    println(apaLulus)



}