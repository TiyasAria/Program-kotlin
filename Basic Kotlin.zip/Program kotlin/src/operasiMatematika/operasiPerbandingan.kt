package operasiMatematika

fun main() {
    val a = 250
    val b = 300
    val result  = a > b
    println(result)
// bisa juga  pakai string
    println("a" > "b") // false
    println("a" < "b") // true
    println( "a" == "a")
    println( "a" != "a") //!Artinya kebalikannya karena a = a true, mka kebalikannya false//
    println( "a" != "b")
}