package Branching

fun main() {
    // syntax if else //
    val nilaiUjian = 75
    if (nilaiUjian > 80) {
        println("baguss pinter sekali")
    } else {
        println(" tetap sabar semangat, Allah bersamamu :)")
    }
    // syntax else if berlaku untuk kondisi if yang banyak //
    val nilaiRapot = 45
    if (nilaiRapot > 75) {
        println(" you getting score A")
    } else if (nilaiRapot > 50) {
        println(" you getting score B")
    } else if (nilaiRapot > 25) {
        println(" you getting score C")
    }else if (nilaiRapot > 0) {
        println(" you getting score A, you must study hard")
    }
}
