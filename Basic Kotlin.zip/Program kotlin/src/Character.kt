fun main(){
    var char1 : Char = 'I'
    var char2 : Char = 'D'
    var char3 : Char = 'N'
    var char4 : Char = ' '
    var char5 : Char = 'A'
    var char6 : Char = 'K'
    var char7 : Char = 'H'
    var char8 : Char = 'W'
    var char9 : Char = 'A'
    var char10 : Char = 'T'

    print(char1)
    print(char2)
    print(char3)
    print(char4)
    print(char5)
    print(char6)
    print(char7)
    print(char8)
    print(char9)
    print(char10)



}