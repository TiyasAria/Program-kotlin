package Looping

fun main() {
    for (data in 1..5) println("asyeek")
    for (number in 1..10) println(number)
}