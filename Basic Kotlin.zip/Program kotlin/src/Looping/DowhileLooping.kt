package Looping

fun main() {
    //var angka = 0
    var angka = 6
    do {
        
        println("asyeek")
        angka ++
    } while (angka < 5 )
/*
ketika bernilai true akan menampilkan asyeek sebanyak 5 kali , karena 0 - <5 ada 4
terus ditambah ++ ditambah 1 jadinya muncul 5
 */
    /*
    sedang klau kita masukan false akan tetap menjalankan satu kali saja karena membaca perintah
    dari si do, berbeda while yang false tidak akan menapilkan sesuatu
     */
}