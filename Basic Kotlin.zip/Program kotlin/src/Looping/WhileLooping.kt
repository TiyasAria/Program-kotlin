package Looping

fun main() {
    // syntax while looping
    var angka = 4
    while ( angka <= 5) {
        println("horass berhasil")
        break


    }


}
