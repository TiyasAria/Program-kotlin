package Function

fun perkalian ( a: Int) : Int = a * 2
fun nama ( name : String) : String = "Tiyas "

fun main() {
    //var hasil = perkalian(10)//
    //println(hasil)//
    println(perkalian(10))
    nama("tiyas ")
}
// function satu baris ajaa yg simple//