package Function

fun satu (){
}

fun main() {
    fun sayKhoir (name : String){
        println("hello $name")
    }
    sayKhoir("Tiyas aria")
}