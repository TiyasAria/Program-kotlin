package Function

fun main() {
    fun factorialLoop (value: Int) : Int{
        var result = 1
        //perulangan
        for (y in value downTo 1){
            result *= y
        }
        return result
    }
    println(factorialLoop(10)) //10x9x8x7 smapai 1

    //recursive function
    fun factorialRecursive (value : Int ) : Int{
        return when(value){
            1 -> 1
            else -> value * factorialRecursive(value-1)
        }
    }
    println(factorialRecursive(10))
}