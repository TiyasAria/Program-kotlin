package Function

fun String.hii() : String = "Hi :) $this"
fun String.printHii() : Unit = println("Hi hello :) $this")
fun main() {
    val name = "Tiyas Aria"
    println(name.hii())
    name.printHii()
    "Pratiwi".printHii()

}